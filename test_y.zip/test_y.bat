@echo off
echo Pwnd >> "%~dp0pwnd.txt"